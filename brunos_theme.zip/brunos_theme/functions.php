<?php 

/* WIDGETS */
if(function_exists('register_sidebar')){
	register_sidebar(array());
}


/* imagem destacada */

add_theme_support('post-thumbnails');

 ?>