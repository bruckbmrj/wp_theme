<div id="footer">
		
		<div id="footer-content">

			<div id="title-footer">
			<span><img src="<?php bloginfo('template_url'); ?>/images/logo-footer.png " title="" alt=""></span>
			</div>

			<div id="footer-bio">
			
				<div id="title-bio">
					<span>Sobre Nós</span>
				</div>

				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Exercitationem, vel recusandae, quos mollitia deleniti quibusdam!</p>

				<p>Lorem ipsum dolor sit amet,  Ab nihil consectetur adipisicing elit. Expedita placeat vel recusandae, ipsum aliquid aliquam natus.</p>

			</div>

			<div id="footer-pages">
				<div id="title-page">
					<span>Paginas</span>
				</div>

				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">Serviços</a></li>
					<li><a href="#">Sobre Nós </a></li>
					<li><a href="#">Arquivos</a></li>
					<li><a href="#">Contato</a></li>
				</ul>
			</div>

			<div id="footer-posts">
				<div id="title-posts">
					<span>Posts Recentes</span>
				</div>
				
				<ul>
					<li><a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</a></li>
					<li><a href="#">Quam voluptas animi voluptates accusamus eos provident, nam totam odio ab.</a></li>
					<li><a href="#">soluta sint quae commodi minima provident dicta repudiandae fuga ad, nemo cumque?</a></li>
				</ul>

			</div>

			<div id="footer-social">
			Social
			</div>
		</div> <!-- fim footer -->

		<div id="footer-info">
			
			<div id="info-content">
				<span>Lorem ipsum dolor sit amet. 2017</span>
				<span class="info-right">Desenvolvido por <b>Bruno Braga</b> </span>
			</div>

		</div><!-- fim footer info -->
	</div> <!--fim footer -->