<div id="footer">
		
		<div id="footer-content">
			<div id="footer-bio">
			Sobre nós
			</div>

			<div id="footer-pages">
			Paginas
			</div>

			<div id="footer-posts">
			Posts Recentes
			</div>

			<div id="footer-social">
			Social
			</div>
		</div> <!-- fim footer -->

		<div id="footer-info">
			Copyright
		</div><!-- fim footer info -->
	</div> <!--fim footer -->