		<div id="sidebar">
			<div id="sidebar-vistos">
				mais vistos
			</div>
			
			<div id="sidebar-categoria1">
				categoria 1
			</div>

			<div id="sidebar-publicidade">
				Publicidade
			</div>

			<div id="sidebar-categoria2">
				categoria 2
			</div>

			<div id="sidebar-facebook">
				Facebook
			</div>

		</div> <!-- fim da sidebar -->