	<div id="header">
		
		<div id="header-superior">
			<div id="header-superior-content">
				<div id="header-paginas">
					<ul>
						<li><a href="#">Home</a></li>
						<li><a href="#">Link2</a></li>
						<li><a href="#">Link3</a></li>
						<li><a href="#">Link4</a></li>
						<li><a href="#">Link5</a></li>
					</ul>
				</div>

				<div id="header-social">
					<a href=""><img src="<?php bloginfo('template_url'); ?>/images/social.png" alt=""></a>
					<a href=""><img src="<?php bloginfo('template_url'); ?>/images/instagram-social-network-logo-of-photo-camera.png" alt=""></a>
					<a href=""><img src="<?php bloginfo('template_url'); ?>/images/twitter-logo.png" alt=""></a>
					<a href=""><img src="<?php bloginfo('template_url'); ?>/images/youtube-logo.png" alt=""></a>
				</div>

			</div>
		</div>

		<div id="header-contet">
			<div id="logo">
				Logo
			</div>

			<div id="login">
				Login
			</div>

			<div id="search">
				Search
			</div>
		</div>

		<div id="nav">
			<div id="nav-content">
				Barra de navegação
			</div>
		</div> 

	</div> <!-- Fim header -->