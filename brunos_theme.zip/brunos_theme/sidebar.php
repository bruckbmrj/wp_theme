		<div id="sidebar">

			<div id="sidebar-vistos">

				<div id="title-vistos"><span>Posts Mais vistos</span></div>

				<ul>
					<li>
					<span class="vistos-number">1</span>
					<a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</a>
					</li>

					<li>
					<span class="vistos-number">2</span>
					<a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</a>
					</li>

					<li>
					<span class="vistos-number">3</span>
					<a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</a>
					</li>

					<li>
					<span class="vistos-number">4</span>
					<a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</a>
					</li>

					<li>
					<span class="vistos-number">5</span>
					<a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</a>
					</li>
				</ul>

			</div>
			
			<div id="sidebar-colunistas">
				<div id="title-colunistas">
					<span>Colunistas</span>	
				</div>
				<div class="colunistas">
					
					<ul>
						<li>
							<img src="<?php bloginfo('template_url'); ?>/images/colunista1.png" rel="" title="" alt=""  />
							<h1><a href="#">Vincent Van Doido</a></h1>

							<div class="info-colunistas">
								<ul>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/facebook.png" title="" alt=""></a>
									</li>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/google+.png" title="" alt=""></a>
									</li>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/twitter.png" title="" alt=""></a>
									</li>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/youtube.png" title="" alt=""></a>
									</li>
								</ul>
							</div>

						</li>


						<li>
							<img src="<?php bloginfo('template_url'); ?>/images/colunista2.png" rel="" title="" alt=""  />
							<h1><a href="#">Cleyton</a></h1>

							<div class="info-colunistas">
								<ul>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/facebook.png" title="" alt=""></a>
									</li>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/google+.png" title="" alt=""></a>
									</li>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/twitter.png" title="" alt=""></a>
									</li>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/youtube.png" title="" alt=""></a>
									</li>
								</ul>
							</div>

						</li>

						<li>
							<img src="<?php bloginfo('template_url'); ?>/images/colunista1.png" rel="" title="" alt=""  />
							<h1><a href="#">Vincent Van Doido</a></h1>

							<div class="info-colunistas">
								<ul>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/facebook.png" title="" alt=""></a>
									</li>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/google+.png" title="" alt=""></a>
									</li>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/twitter.png" title="" alt=""></a>
									</li>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/youtube.png" title="" alt=""></a>
									</li>
								</ul>
							</div>

						</li>

						<li>
							<img src="<?php bloginfo('template_url'); ?>/images/colunista2.png" rel="" title="" alt=""  />
							<h1><a href="#">Cleyton</a></h1>

							<div class="info-colunistas">
								<ul>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/facebook.png" title="" alt=""></a>
									</li>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/google+.png" title="" alt=""></a>
									</li>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/twitter.png" title="" alt=""></a>
									</li>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/youtube.png" title="" alt=""></a>
									</li>
								</ul>
							</div>

						</li>

						<li>
							<img src="<?php bloginfo('template_url'); ?>/images/colunista2.png" rel="" title="" alt=""  />
							<h1><a href="#">Cleyton</a></h1>

							<div class="info-colunistas">
								<ul>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/facebook.png" title="" alt=""></a>
									</li>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/google+.png" title="" alt=""></a>
									</li>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/twitter.png" title="" alt=""></a>
									</li>
									<li>
										<a href="#"> <img src="<?php bloginfo('template_url'); ?>/images/youtube.png" title="" alt=""></a>
									</li>
								</ul>
							</div>

						</li>

					</ul>

				</div>
			</div> <!-- fim colunistas -->

			<div id="sidebar-publicidade">
				<div id="title-publi"><span>Publicidade</span></div>

				<ul>
					<li class="publi-maior">Publicidade Maior</li>
					<li class="publi-left">Publicidade left</li>
					<li class="publi-right">Publicidade right</li>	
				</ul>

			</div> <!-- fim publicidade -->

			<div id="sidebar-coment">

				<div id="title-coment"><span>Mais Comentados</span></div>

				<ul>
					<li>
					<span class="coment-number">1</span>
					<a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</a>
					</li>

					<li>
					<span class="coment-number">2</span>
					<a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</a>
					</li>

					<li>
					<span class="coment-number">3</span>
					<a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</a>
					</li>

					<li>
					<span class="coment-number">4</span>
					<a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</a>
					</li>

					<li>
					<span class="coment-number">5</span>
					<a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</a>
					</li>
				</ul>
			</div> <!-- fim comentários -->

			<div id="sidebar-facebook">
				<div id="title-facebook"><span>Facebook</span></div>
				
				<div id="face-box">
				<div class="fb-page" data-href="https://www.facebook.com/viladosite/" data-tabs="like" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/viladosite/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/viladosite/">Vila do Site</a></blockquote></div>
				</div>

			</div>

		</div> <!-- fim da sidebar -->